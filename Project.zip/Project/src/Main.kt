import javax.swing.text.StyledEditorKit.BoldAction
import kotlin.random.Random

var numLinhas = -1
var numColunas = -1
var tabuleiroHumano: Array<Array<Char?>> = emptyArray()
var tabuleiroComputador: Array<Array<Char?>> = emptyArray()

var tabuleiroPalpitesDoHumano: Array<Array<Char?>> = emptyArray()
var tabuleiroPalpitesDoComputador: Array<Array<Char?>> = emptyArray()


fun tamanhoTabuleiroValido(numLinhas: Int, numColunas: Int): Boolean {
    if (numColunas == 4 || numColunas == 5 || numColunas == 7 || numColunas == 8 || numColunas == 10) {
        if (numColunas == numLinhas) {
            return true
        } else {
            return false
        }

    } else {
        return false
    }
}

fun criaLegendaHorizontal(numColunas: Int): String {
    var legenda = ""
    var countColunas = 0
    while (countColunas < numColunas) {
        val char = ('A' + countColunas).toChar()
        if (countColunas + 1 == numColunas) {
            legenda += "$char"
        } else {
            legenda += "$char | "
        }

        countColunas++
    }
    return legenda
}

fun criaTerreno(numLinhas: Int, numColunas: Int): String {
    var terreno: String = ""
    var countColunas = 0
    var countLinhas = 0
    terreno += "\n"
    while (countColunas < numColunas) {
        val char = ('A' + countColunas).toChar()
        terreno += "| $char "
        countColunas++
    }
    terreno += "|"
    terreno += "\n"
    while (countLinhas < numLinhas) {
        countColunas = 0
        terreno += "|   |"
        while (countColunas < numColunas) {
            if (countColunas + 1 == numColunas) {
                terreno += " ${countLinhas + 1}"

            } else {
                terreno += "   |"
            }

            countColunas++

        }
        terreno += "\n"
        countLinhas++
    }
    return terreno
}

fun processaCoordenadas(coordenadas: String, numLinhas: Int, numColunas: Int): Pair<Int, Int>? {
    val separador = coordenadas.indexOf(',')
    if (separador == -1 || separador == 0 || separador == coordenadas.length - 1) {
        return null
    }

    val linhaStr = coordenadas.substring(0, separador)
    val colunaStr = coordenadas.substring(separador + 1)

    val linha = linhaStr.toIntOrNull()
    val coluna = colunaStr.firstOrNull()?.toUpperCase()

    if (linha != null && coluna != null &&
        linha in 1..numLinhas &&
        coluna in 'A'..'Z' &&
        coluna - 'A' + 1 <= numColunas
    ) {
        return linha to (coluna - 'A' + 1)
    }

    return null
}

fun calculaEstatisticas(tabuleiroPalpites: Array<Array<Char?>>): Array<Int> {
    val estatistica = arrayOf(0, 0, 0)
    for (linha in tabuleiroPalpites) {
        for (posicao in linha) {
            if (posicao == '1') {
                estatistica[1]++
                estatistica[2]++
            }
            if (posicao != null) {
                estatistica[0]++
            }
        }
    }
    return estatistica
}

fun calculaNaviosFaltaAfundar(tabuleiroPalpites: Array<Array<Char?>>): Array<Int> {
    val estatistica = arrayOf(0, 0, 0, 0)
    estatistica[3] = 2
    for (linha in tabuleiroPalpites) {
        for (posicao in linha) {
            if (posicao == '1') {
                estatistica[3]--
            }

        }
    }
    return estatistica
}


fun calculaNumNavios(numLinhas: Int, numColunas: Int): Array<Int?> {
    val navios: Array<Int?> = arrayOfNulls(4)
    if (numColunas == 4 && numLinhas == 4) {
        navios[0] = 2
        navios[1] = 0
        navios[2] = 0
        navios[3] = 0
    }
    if (numColunas == 5 && numLinhas == 5) {
        navios[0] = 1
        navios[1] = 1
        navios[2] = 1
        navios[3] = 0
    }
    if (numColunas == 7 && numLinhas == 7) {
        navios[0] = 2
        navios[1] = 1
        navios[2] = 1
        navios[3] = 1
    }
    if (numColunas == 8 && numLinhas == 8) {
        navios[0] = 2
        navios[1] = 2
        navios[2] = 1
        navios[3] = 1
    }
    if (numColunas == 10 && numLinhas == 10) {
        navios[0] = 3
        navios[1] = 2
        navios[2] = 1
        navios[3] = 1
    }
    return navios
}

fun criaTabuleiroVazio(numColunas: Int, numLinhas: Int): Array<Array<Char?>> {
    val tabuleiro: Array<Array<Char?>> = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }

    return tabuleiro
}

fun coordenadaContida(tabuleiro: Array<Array<Char?>>, numLinhas: Int, numColunas: Int): Boolean {
    val linha = numLinhas
    val coluna = numColunas
    if (coluna == 0 || linha == 0)
        return false
    if (linha <= tabuleiro.size && coluna <= tabuleiro.size) {
        return true
    } else {
        return false
    }

}

fun limparCoordenadasVazias(coordenadas: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {

    return coordenadas.filter { it.first != 0 && it.second != 0 }.toTypedArray()
}

fun juntarCoordenadas(array1: Array<Pair<Int, Int>>, array2: Array<Pair<Int, Int>>): Array<Pair<Int, Int>> {
    return array1 + array2
}

fun gerarCoordenadasNavio(
    tabuleiro: Array<Array<Char?>>,
    numLinhas: Int,
    numColunas: Int,
    orientacao: String,
    dimensao: Int
): Array<Pair<Int, Int>> {
    val coordenadas: Array<Pair<Int, Int>> = Array(dimensao) { Pair(0, 0) }

    if (orientacao == "E") {
        for (i in 0 until dimensao) {
            if (numColunas + i <= tabuleiro.size - 1) {
                coordenadas[i] = Pair(numLinhas, numColunas + i)
            }

        }
    }
    if (orientacao == "O") {
        for (i in 0 until dimensao) {
            if (numColunas + i >= 0) {
                coordenadas[i] = Pair(numLinhas, numColunas + i)
            }


        }
    }
    if (orientacao == "S") {
        for (i in 0 until dimensao) {
            if (numLinhas + i <= tabuleiro.size) {
                coordenadas[i] = Pair(numLinhas + i, numColunas)
            }

        }
    }
    if (orientacao == "N") {
        for (i in 0 until dimensao) {
            if (numColunas + i >= 0) {
                coordenadas[i] = Pair(numLinhas, numColunas + i)
            }


        }
    }
    return coordenadas
}

fun gerarCoordenadasFronteira(
    tabuleiro: Array<Array<Char?>>,
    numLinha: Int,
    numColuna: Int,
    orientacao: String,
    dimensao: Int
): Array<Pair<Int, Int>> {
    val coordenadas = mutableListOf<Pair<Int, Int>>()

    if (numLinha < 0 || numLinha > tabuleiro.size || numColuna < 0 || numColuna > tabuleiro[0].size) {
        return coordenadas.toTypedArray()
    }

    for (i in -1..1) {
        for (j in -1..1) {
            if ((i != 0 || j != 0) && (numLinha + i) in 0 until tabuleiro.size && (numColuna + j) in 0 until tabuleiro[0].size) {
                coordenadas.add(numLinha + i to numColuna + j)
            }
        }
    }

    return coordenadas.toTypedArray()


}

fun estaLivre(tabuleiro: Array<Array<Char?>>, coordenadas: Array<Pair<Int, Int>>): Boolean {

    for (par in coordenadas) {
        val linha = par.first - 1
        val coluna = par.second - 1
        if ((linha in tabuleiro.indices) && (coluna in tabuleiro[0].indices)) {
            if (tabuleiro[linha][coluna] == null) {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }
    return true
}

fun insereNavioSimples(tabuleiro: Array<Array<Char?>>, numLinhas: Int, numColunas: Int, dimensao: Int): Boolean {
    var coordenadas: Array<Pair<Int, Int>> = arrayOf(Pair(numLinhas, numColunas))

    if (!estaLivre(tabuleiro, coordenadas)) {
        return false
    } else {
        for (par in coordenadas) {
            val linha = par.first - 1
            val coluna = par.second - 1
            if (linha < 0 || linha >= numLinhas || coluna < 0 || coluna >= numColunas) {
                return false
            }

            if (tabuleiro[linha][coluna] == '1' || (dimensao == 2 && tabuleiro[linha - 1][coluna] == '1')) {
                return false
            }
            tabuleiro[linha][coluna] = '1'
            if (dimensao == 2) {
                tabuleiro[linha - 1][coluna] = '1'
            }
        }
        tabuleiroHumano = tabuleiro
        return true
    }

}

fun insereNavio(
    tabuleiro: Array<Array<Char?>>,
    numLinhas: Int,
    numColunas: Int,
    orientacao: String,
    dimensao: Int
): Boolean {
    return true
}

fun preencheTabuleiroComputador(tabuleiro: Array<Array<Char?>>, navios: Array<Int>) {
    val nOrientacao = (1..4).random()
    var orientacao: String = ""
    val coordenadas = Array<Pair<Int, Int>>(navios[0]) { Pair(0, 0) }
    val random1 = (0..tabuleiro.size - 1).random()
    val random2 = (0..tabuleiro.size - 1).random()
    var estaCerto: Boolean = false
    when (nOrientacao) {
        1 -> orientacao = "E"
        2 -> orientacao = "O"
        3 -> orientacao = "N"
        4 -> orientacao = "S"
    }
    val coordenadasBloqueadas =
        gerarCoordenadasFronteira(tabuleiro, random1, random2, orientacao, navios[0])

    tabuleiro[random1][random2] = '1'
    val par = Pair(random1, random2)
    var linha1: Int
    var coluna1: Int
    do {
        linha1 = (0..tabuleiro.size - 1).random()
        coluna1 = (0..tabuleiro.size - 1).random()
        val novoPar = Pair(linha1, coluna1)
        if (!(coordenadasBloqueadas.contains(novoPar))) {
            if (novoPar != par) {
                tabuleiro[linha1][coluna1] = '1'

            }
        }

    } while (coordenadasBloqueadas.contains(novoPar) || novoPar == par)


}

fun navioCompleto(tabuleiro: Array<Array<Char?>>, numLinhas: Int, numColunas: Int): Boolean {
    val linha = numLinhas - 1
    val coluna = numColunas - 1
    if (linha <= tabuleiro.size - 1 && coluna <= tabuleiro.size - 1) {
        if (tabuleiro[linha][coluna] == '1' || tabuleiro[linha][coluna] == '2' || tabuleiro[linha][coluna] == '3' || tabuleiro[linha][coluna] == '4') {
            return true

        }
    }

    return false
}

fun obtemMapa(tabuleiro: Array<Array<Char?>>, palpite: Boolean): Array<String> {
    val mapa = Array(tabuleiro.size + 1) { "" }

    var legenda = "| "
    var countColunas = 0
    while (countColunas < tabuleiro[0].size) {
        val char = ('A' + countColunas).toChar()
        if (countColunas + 1 == tabuleiro[0].size) {
            legenda += "$char |"
        } else {
            legenda += "$char | "
        }

        countColunas++
    }
    mapa[0] = legenda
    for (i in 1 until mapa.size) {
        var linha = "| "
        for (j in 0 until tabuleiro[0].size) {
            val valor = tabuleiro[i - 1][j]

            val char = when {
                valor == null -> if (palpite) {
                    '~'
                } else {
                    '?'
                }

                else -> valor.toChar()
            }
            linha += "$char | "
        }
        linha += "$i"
        mapa[i] = linha
    }

    return mapa

}

fun lancarTiro(
    tabuleiroReal: Array<Array<Char?>>,
    tabuleiroPalpite: Array<Array<Char?>>,
    coordenadas: Pair<Int, Int>
): String {
    val linha = coordenadas.first - 1
    val coluna = coordenadas.second - 1

    if (tabuleiroReal[linha][coluna] != null) {
        if (tabuleiroReal[linha][coluna] == '1') {
            tabuleiroPalpite[linha][coluna] = '1'
            return "Tiro num submarino."
        } else {
            if (tabuleiroReal[linha][coluna] == '2') {
                tabuleiroPalpite[linha][coluna] = '2'
                return "Tiro num contra-torpedeiro"
            } else {
                if (tabuleiroReal[linha][coluna] == '3') {
                    tabuleiroPalpite[linha][coluna] = '3'
                    return "Tiro num navio-tanque."
                } else {
                    if (tabuleiroReal[linha][coluna] == '4') {
                        tabuleiroPalpite[linha][coluna] = '4'
                        return "Tiro num porta-avioes."
                    }
                }
            }
        }
    }
    tabuleiroPalpite[linha][coluna] = 'X'
    return "Agua."
}

fun geraTiroComputador(tabuleiroComputador: Array<Array<Char?>>): Pair<Int, Int> {
    while (true) {
        val linhaRandom = (0..tabuleiroComputador.size - 1).random()
        val colunaRandom = (0..tabuleiroComputador[0].size - 1).random()
        if (tabuleiroComputador[linhaRandom][colunaRandom] == null || tabuleiroComputador[linhaRandom][colunaRandom] == ' ') {
            return Pair(linhaRandom + 1, colunaRandom + 1)
        }
    }
}


fun contarNaviosDeDimensao(tabuleiroPalpite: Array<Array<Char?>>, dimensao: Int): Int {

    var contador: Int = 0
    for (linha in tabuleiroPalpite.indices) {
        for (coluna in tabuleiroPalpite[linha].indices) {
            if (tabuleiroPalpite[linha][coluna] == '1') {
                contador += 1
            }
        }
    }
    return contador
}

fun venceu(tabuleiroPalpite: Array<Array<Char?>>): Boolean {
    var numNav = calculaNumNavios(tabuleiroPalpite.size, tabuleiroPalpite[0].size)
    if (contarNaviosDeDimensao(tabuleiroPalpite, 1) == numNav[0]) {
        return true
    }
    return false
}

fun lerJogo(nome: String, TipoTabuleiro: Int): Array<Array<Char?>> {
    val s: Array<Array<Char?>> = arrayOf(
        arrayOf('A', 'f'),
        arrayOf('A', 'f'),
        arrayOf('A', 'f')
    )


    return s
}

fun gravarJogo(
    nome: String,
    tabuleiroRealHumano: Array<Array<Char?>>,
    tabuleiroPalpitesHumano: Array<Array<Char?>>,
    tabuleiroRealComputador: Array<Array<Char?>>,
    tabuleiroPalpitesComputador: Array<Array<Char?>>
) {

}

fun menuPrincipal() {
    println("")
    println("> > Batalha Naval < <")
    println("")

    println("1 - Definir Tabuleiro e Navios")
    println("2 - Jogar")
    println("3 - Gravar")
    println("4 - Ler")
    println("0 - Sair")
    println()
}

fun main() {
    menuPrincipal()
    do {
        var resposta = readln().toIntOrNull()
        var colunas: Int? = 0
        var linhas: Int? = 0

        if (resposta != null) {
            when (resposta) {
                1 -> {
                    println("")
                    println("> > Batalha Naval < <")
                    println("")
                    println("Defina o tamanho do tabuleiro:")
                    var countDO = 0
                    do {
                        if (countDO > 0) {
                            println("!!! Numero de linhas invalidas, tente novamente")
                        } else {
                            println("Quantas linhas?")
                        }
                        val userput = readln()
                        numLinhas = userput.toInt()
                        if (numLinhas > 0) {
                            countDO++
                        }

                        countDO++
                    } while (numLinhas != -1 && numLinhas != 4 && numLinhas != 5 && numLinhas != 7 && numLinhas != 8 && numLinhas != 10)
                    if (numLinhas != -1) {
                        countDO = 0
                        do {
                            if (countDO > 0) {
                                println("!!! Numero de colunas invalidas, tente novamente")
                            } else {
                                println("Quantas colunas?")
                            }
                            val userput = readln()
                            numColunas = userput.toInt()
                            if (numColunas != null) {
                                countDO++
                            }
                            countDO++
                        } while (numColunas != -1 && numColunas != 4 && numColunas != 5 && numColunas != 7 && numColunas != 8 && numColunas != 10)
                        if (numColunas != -1) {

                            tabuleiroHumano = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }
                            val tabu = obtemMapa(tabuleiroHumano, false)
                            verTabuleiro(tabu, tabuleiroHumano, true)
                            var coordenada: String
                            var countC = 0
                            var counwhile = 0
                            do {
                                if (counwhile > 0) {
                                    println("!!! Coordenadas invalidas, tente novamente")
                                    println("Coordenadas? (ex: 6,G)")

                                } else {
                                    println("Insira as coordenadas de um submarino:")
                                    println("Coordenadas? (ex: 6,G)")
                                }
                                coordenada = readln().uppercase()
                                val navioCoordenada = processaCoordenadas(coordenada, numLinhas, numColunas)
                                if (navioCoordenada != null) {
                                    if (insereNavioSimples(
                                            tabuleiroHumano,
                                            navioCoordenada.first,
                                            navioCoordenada.second,
                                            1
                                        )
                                    ) {
                                        verTabuleiro(tabu, tabuleiroHumano, true)
                                        countC++
                                    } else {
                                        counwhile++
                                    }
                                } else {
                                    counwhile++
                                }

                            } while (countC < 1)
                            countC = 0
                            counwhile = 0
                            do {
                                if (counwhile > 0) {
                                    println("!!! Coordenadas invalidas, tente novamente")
                                    println("Coordenadas? (ex: 6,G)")

                                } else {
                                    println("Insira as coordenadas de um submarino:")
                                    println("Coordenadas? (ex: 6,G)")
                                }
                                coordenada = readln().uppercase()
                                val navioCoordenada = processaCoordenadas(coordenada, numLinhas, numColunas)
                                if (navioCoordenada != null) {
                                    if (insereNavioSimples(
                                            tabuleiroHumano,
                                            navioCoordenada.first,
                                            navioCoordenada.second,
                                            1
                                        )
                                    ) {
                                        verTabuleiro(tabu, tabuleiroHumano, true)
                                        countC++
                                    } else {
                                        counwhile++
                                    }
                                } else {
                                    counwhile++
                                }

                            } while (countC < 1)
                            var respostaSN = ""
                            do {
                                println("Pretende ver o mapa gerado para o Computador? (S/N)")
                                respostaSN = readln().toUpperCase()
                            } while (respostaSN != "S" && respostaSN != "N")
                            tabuleiroComputador = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }
                            preencheTabuleiroComputador(tabuleiroComputador, arrayOf(0, 0, 0, 2))
                            if (respostaSN == "S") {

                                val tabul = obtemMapa(tabuleiroComputador, false)
                                verTabuleiro(tabul, tabuleiroComputador, true)
                                menuPrincipal()
                            } else {
                                menuPrincipal()
                            }

                        } else {
                            menuPrincipal()
                        }
                    } else {
                        menuPrincipal()
                    }
                }

                2 -> {
                    if (numColunas < 0 && numLinhas < 0) {
                        println("!!! Tem que primeiro definir o tabuleiro do jogo, tente novamente")
                    } else {
                        tabuleiroPalpitesDoHumano = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }
                        tabuleiroPalpitesDoComputador = Array(numLinhas) { arrayOfNulls<Char?>(numColunas) }
                        val tabuleiroC = obtemMapa(tabuleiroPalpitesDoHumano, true)
                        verTabuleiro(tabuleiroC, tabuleiroPalpitesDoHumano, false)

                        var countC = 0
                        var counwhile = 0
                        var coordenadaTiro = ""
                        while (!venceu(tabuleiroPalpitesDoHumano) && !venceu(tabuleiroPalpitesDoComputador)) {
                            if (counwhile > 0) {
                                println("!!! Coordenadas invalidas, tente novamente")
                                println("Coordenadas? (ex: 6,G)")

                            } else {
                                println("Indique a posição que pretende atingir")
                                println("Coordenadas? (ex: 6,G)")
                            }
                            coordenadaTiro = readln().uppercase()
                            val navioCoordenada = processaCoordenadas(coordenadaTiro, numLinhas, numColunas)
                            if(coordenadaTiro=="?")
                            {
                                var falta=calculaNaviosFaltaAfundar(tabuleiroPalpitesDoHumano)
                                println("Falta afundar: ${falta[3]} submarino(s)")
                            }
                            else
                            {
                                if (navioCoordenada != null) {

                                    val acertouHumano =
                                        lancarTiro(tabuleiroComputador, tabuleiroPalpitesDoHumano, navioCoordenada)
                                    if(acertouHumano=="Tiro num submarino.")
                                    {
                                        println(">>> HUMANO >>>$acertouHumano Navio ao fundo!")
                                    }
                                    else
                                    {
                                        println(">>> HUMANO >>>$acertouHumano")
                                    }
                                    if (venceu(tabuleiroPalpitesDoHumano)) {
                                        println("PARABENS! Venceu o jogo!")
                                        break
                                    }
                                    val tiro=geraTiroComputador(tabuleiroPalpitesDoComputador)
                                    val acertouComputador = lancarTiro(
                                        tabuleiroHumano,
                                        tabuleiroPalpitesDoComputador,
                                        tiro
                                    )
                                    println("Computador lancou tiro para a posicao $tiro")
                                    if(acertouComputador=="Tiro num submarino.")
                                    {
                                        println(">>> Computador >>>$acertouComputador ")
                                    }
                                    else
                                    {
                                        println(">>> Computador >>>$acertouComputador")
                                    }

                                    if (venceu(tabuleiroPalpitesDoHumano)) {
                                        println("OPS! O computador venceu o jogo!")
                                        break
                                    }
                                    println("Prima enter para continuar")
                                    readLine()

                                    verTabuleiro(tabuleiroC, tabuleiroPalpitesDoHumano, false)

                                } else {
                                    counwhile++
                                }
                            }

                        }

                        println("Prima enter para voltar ao menu principal")
                        readLine()

                    }


                    menuPrincipal()
                }

                3 -> {
                    println("!!! POR IMPLEMENTAR, tente novamente")
                    menuPrincipal()
                }

                4 -> {
                    println("!!! POR IMPLEMENTAR, tente novamente")
                    menuPrincipal()
                }

                0 -> resposta = 0
                else -> println("!!! Opcao invalida, tente novamente")
            }
        } else {
            println("!!! Opcao invalida, tente novamente")
        }
    } while (resposta != 0)
}

fun verTabuleiro(ver: Array<String>, tabuleiro: Array<Array<Char?>>, eReal: Boolean) {
    obtemMapa(tabuleiro, eReal).forEach {
        println(it)
    }
}

fun navioHabilitado(coordenadas: Array<Pair<Int, Int>>, par: Pair<Int, Int>): Boolean {

    if (coordenadas.contains(par)) {
        return false
    }
    return true
}